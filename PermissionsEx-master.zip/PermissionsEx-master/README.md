PermissionsEx is a powerful permissions plugin for Bukkit powered servers

For instructions see [the wiki](https://github.com/PEXPlugins/PermissionsEx/wiki)
