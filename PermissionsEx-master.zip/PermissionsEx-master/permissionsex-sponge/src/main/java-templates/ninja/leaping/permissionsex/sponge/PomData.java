package ninja.leaping.permissionsex.sponge;

class PomData {
	public static final String ARTIFACT_ID = "${plugin.id}";
	public static final String NAME = "${project.parent.name}";
	public static final String VERSION = "${project.version}${version.suffix}";
}
