package com.nisovin.magicspells.mana;

public enum ManaChangeReason {

	REGEN,
	SPELL_COST,
	POTION,
	OTHER
	
}
