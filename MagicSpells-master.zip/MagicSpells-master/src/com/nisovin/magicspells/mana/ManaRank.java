package com.nisovin.magicspells.mana;

import org.bukkit.ChatColor;

public class ManaRank {
	String name;
	int startingMana;
	int maxMana;
	int regenAmount;
	String prefix;
	ChatColor colorFull;
	ChatColor colorEmpty;
}