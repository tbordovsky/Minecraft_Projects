package com.nisovin.magicspells.spells;

public class ChanneledSpell {

}
