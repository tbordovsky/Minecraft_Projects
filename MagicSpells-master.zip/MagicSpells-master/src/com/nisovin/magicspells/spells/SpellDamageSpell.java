package com.nisovin.magicspells.spells;

public interface SpellDamageSpell {

	public String getSpellDamageType();
	
}
