package com.nisovin.magicspells.reagents;

import org.bukkit.entity.Player;

public class ItemReagent extends Reagent {

	public ItemReagent() {
		
	}
	
	@Override
	public boolean has(Player player, int amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(Player player, int amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
