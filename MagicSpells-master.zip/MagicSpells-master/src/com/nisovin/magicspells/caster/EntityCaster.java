package com.nisovin.magicspells.caster;

import org.bukkit.entity.Entity;

public abstract class EntityCaster extends Caster {

	public abstract Entity getEntity();
	
}
