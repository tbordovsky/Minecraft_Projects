MagicSpells
===========

MagicSpells is a Bukkit plugin that allows you to set up a magic system, and much more. The plugin is very configurable and flexible.
This plugin has nearly endless possibilities.

BukkitDev Page: http://dev.bukkit.org/bukkit-plugins/magicspells/  
Configuration Documentation: http://nisovin.com/magicspells/  
Forums: http://nisovin.com/forums/index.php?forums/magicspells/  
Release Downloads: http://dev.bukkit.org/bukkit-plugins/magicspells/files/  
Dev Builds: http://nisovin.com/magicspells/dev/  

Building
--------

First, you will need to download the required dependencies and place them in the lib folder. You can see a list of download links
in lib/library_urls.txt. You can then use the ant build file (build.xml) to build the plugin. It places the compiled jar file
in the dist folder.